# for testing
vlc -v rtsp://127.0.0.1:8554/mjpeg/1
