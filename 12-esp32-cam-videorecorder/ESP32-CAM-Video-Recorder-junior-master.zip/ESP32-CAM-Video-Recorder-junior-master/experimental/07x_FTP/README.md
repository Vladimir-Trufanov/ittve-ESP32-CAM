Nov 29, 2021 - add dates and times to files delivered over ftp.

Buy me a coffee?  https://www.buymeacoffee.com/jameszah

The folder 07x_FTP is a the version 7 discussed in the main readme, but it adds an ftp server host.

Set up your ftp client in passive mode and connect to the ip address of the esp32.
